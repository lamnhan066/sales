class InvalidServerConnectionException implements Exception {
  final String message;
  const InvalidServerConnectionException(this.message);
}
