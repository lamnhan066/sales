class InvalidServerConfigurationsException implements Exception {
  final String message;
  const InvalidServerConfigurationsException(this.message);
}
