class CredentialsException implements Exception {
  final String message;

  const CredentialsException(this.message);
}
