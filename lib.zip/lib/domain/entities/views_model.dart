/// Màn hình.
enum ViewsModel {
  /// Tổng quan.
  dashboard,

  /// Sản phẩm.
  products,

  /// Đơn hàng.
  orders,

  /// Báo cáo.
  report,

  /// Cài đăt.
  settings;
}
