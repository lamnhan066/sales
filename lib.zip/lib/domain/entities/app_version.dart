class AppVersion {
  final String version;

  const AppVersion({required this.version});
}
