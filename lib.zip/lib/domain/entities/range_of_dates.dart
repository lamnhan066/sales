import 'package:sales/domain/entities/ranges.dart';

/// Khoảng thời gian.
typedef RangeOfDates = Ranges<DateTime>;
