import 'package:flutter/material.dart';

/// Màn hình cài đặt.
class SettingsView extends StatefulWidget {
  /// Màn hình cài đặt.
  const SettingsView({super.key});

  @override
  State<SettingsView> createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
