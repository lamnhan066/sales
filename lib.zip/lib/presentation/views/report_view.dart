import 'package:flutter/material.dart';

/// Màn hình báo cáo.
class ReportView extends StatefulWidget {
  /// Màn hình báo cáo.
  const ReportView({super.key});

  @override
  State<ReportView> createState() => _ReportViewState();
}

class _ReportViewState extends State<ReportView> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
